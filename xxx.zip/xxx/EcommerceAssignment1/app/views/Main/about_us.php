<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex; 
            width: 100vw; 
            height: 100vh; 
        }

        .nav {
            background-color: #f8f9fa; 
            width: 200px; 
            padding: 20px; 
        }

        .nav ul {
            list-style: none; 
            margin: 0; 
            padding: 0; 
        }

        .nav li {
            margin-bottom: 10px; 
        }

        .nav li a {
            text-decoration: none; 
            color: #495057; 
            display: block; 
            padding: 10px; 
        }

        .main-content {
            flex: 1; 
            padding: 20px; 
        }

        .main-content h1 {
            margin-bottom: 20px; 
        }

        .about-us {
            display: flex;
            flex-direction: column; 
            align-items: center;
        }

        .about-us-text {
            width: 80%; 
            text-align: center; 
            margin-bottom: 20px; 
        }

        .about-us-image {
            width: 80%; 
            margin-bottom: 20px; 
        }

        .about-us-image img {
            width: 100%;
            height: auto;
            display: block;
            margin-bottom: 10px;
            border-radius: 5px; 
        }
    </style>
    
</head>
<body>
    <div class="container">
        <nav class="nav">
            <ul>
                <li><a href="/Main/index">Landing Page</a></li>
                <li><a href="/Main/about_us">About Us</a></li>
                <li><a href="/Contact/index">Contact Us</a></li>
                <li><a href="/Contact/read">See the messages we got</a></li>
            </ul>
        </nav>
        <main class="main-content">
            <h1>About Us</h1>
            <div class="about-us">
                <div class="about-us-text">
                    <p>About os page.</p>
                    <p>The team consist of Arjun and Michael</p>
                </div>
                <div class="about-us-image">
                    <img src="../../student1.jpg" alt="First Image">
                    <p>Arjun</p>
                </div>
                <div class="about-us-image">
                    <img src="../../student2.jpg" alt="Second Image">
                    <p>Micheal</p>
                </div>
            </div>
        </main>
    </div>

   
</body>
</html>
