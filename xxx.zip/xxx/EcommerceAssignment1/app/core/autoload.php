<?php
spl_autoload_register(function ($class_name) {
    $class_file = str_replace('\\', DIRECTORY_SEPARATOR, $class_name) . '.php';

    if (file_exists($class_file)) {
        require_once $class_file;
        return true;
    } else {
        return false;
    }
});
?>