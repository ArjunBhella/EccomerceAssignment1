<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Message;

class ContactController extends Controller
{
    public function index()
    {
        $this->view('Contact/index');
        $counter = new Counter(); 

       

    }

    public function read()
    {
        $message = new Message();

        $messages = $message->read();



        $this->view('Contact/read', ['messages' => $messages]);
    }

    public function submit()
    {
        $message = new Message();

        $message->name = $_POST['name'];

        $message->email = $_POST['email'];

        $message->IP = $_SERVER['REMOTE_ADDR'];

        $message->message = $_POST['message'];

        
        $message->write();

        
        header('Location: /Contact/read');
    }
}

?>


