<?php

namespace app\models;

class Counter
{
    public $count;

    public function __construct()
    {
        $counterFile = '../resources/counter.txt';

        if (file_exists($counterFile)) {

            $fileHandle = fopen($counterFile, 'r');

            flock($fileHandle, LOCK_SH);
            
            $this->count = json_decode(fread($fileHandle, filesize($counterFile)))->count;
            flock($fileHandle, LOCK_UN);
            fclose($fileHandle);
        } else {
            $this->count = 0;
        }
    }

    public function increment()
    {
        $this->count++;
    }

    public function write()
    {
        $counterFile = '../resources/counter.txt';
        $fileHandle = fopen($counterFile, 'w');
        flock($fileHandle, LOCK_EX);
        fwrite($fileHandle, json_encode(['count' => $this->count]));
        flock($fileHandle, LOCK_UN);
        fclose($fileHandle);
    }

    public function __toString()
    {
        return json_encode(['count' => $this->count]);
    }
}


