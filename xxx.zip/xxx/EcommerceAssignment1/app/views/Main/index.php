<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex; 
            width: 100vw; 
            height: 100vh; 
        }

        .nav {
            background-color: #f0f0f0; 
            width: 200px; 
            padding: 20px; 
        }

        .nav ul {
            list-style: none; 
            margin: 0; 
            padding: 0; 
        }

        .nav li {
            margin-bottom: 10px; 
        }

        .nav li a {
            text-decoration: none; 
            color: black; 
            display: block; 
            padding: 10px; 
        }

        .main-content {
            flex: 1; 
            padding: 20px; 
        }

        .main-content h1 {
            margin-bottom: 20px; 
        }
    </style>
   
</head>
<body>
    <div class="container">
        <nav class="nav">
            <ul>
            <li><a href="/Main/index">Landing Page</a></li>
    <li><a href="/Main/about_us">About Us</a></li>
    <li><a href="/Contact/index">Contact Us</a></li>
    <li><a href="/Contact/read">See the messages we got</a></li>
            </ul>
        </nav>
        <main class="main-content">
            <h1>Landing Page</h1>
            <div class="jumbotron mt-5">
        <h1 class="display-4">Welcome to Our Web App</h1>
        <p class="lead">We are Developperss.</p>
    </div>
        </main>
    </div>
</body>
</html>