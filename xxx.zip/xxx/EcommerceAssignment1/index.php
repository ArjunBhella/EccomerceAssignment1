<?php

use app\core\App;

require('app/core/autoload.php');



$app = new App();

$app->addRoute('Main/index', 'Main,index');
$app->addRoute('Main/about_us', 'Main,aboutUs');
$app->addRoute('Contact/index', 'Contact,index');
$app->addRoute('Contact/read', 'Contact,read');
$app->addRoute('Count/index', 'Count,index'); // didnt implenet this so wont work
$app->addRoute('Contact/submit', 'Contact,submit');

$app->run();
?>