<?php



namespace app\models;

class Message
{
    public $name;
    public $email;
    public $IP;
    public $message;

    public function read()
    {
        $messageFile = __DIR__ . '/../../resources/messages.txt';
        $fileContents = file_get_contents($messageFile);

        if ($fileContents === false) {
            return [];
        }

        $messages = json_decode($fileContents, true);


        return $messages;
    }

    public function write()
    {
        $messageFile = __DIR__ . '/../../resources/messages.txt';
        $messageData = [
            'name' => $this->name,
            'email' => $this->email,
            'IP' => $this->IP,
            'message' => $this->message,
        ];

        $fileContents = file_get_contents($messageFile);
        $messages = json_decode($fileContents, true) ?: [];

        $messages[] = $messageData;

        $messageJson = json_encode($messages, JSON_PRETTY_PRINT) . PHP_EOL;

        $fileHandle = fopen($messageFile, 'w');
     

        flock($fileHandle, LOCK_EX);
        fwrite($fileHandle, $messageJson);
        flock($fileHandle, LOCK_UN);
        fclose($fileHandle);
    }
}
