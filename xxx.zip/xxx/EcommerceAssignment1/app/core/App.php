<?php


namespace app\core;

class App
{
    private $routes = [];

    public function __construct()
    {
        $this->run();
    }

    public function addRoute($url, $handler)
    {
        $url = preg_replace('/{([^\/]+)}/', '(?<$1>[^\/]+)', $url);
        $this->routes[$url] = $handler;
    }

    public function run()
    {
        $url = $_GET['url'] ?? '';

        foreach ($this->routes as $routeUrl => $controllerMethod) {
            if ($url == $routeUrl) {
                [$controller, $method] = explode(',', $controllerMethod);
                $controller = '\\app\\controllers\\' . $controller . 'Controller'; 
                $controller = new $controller();
                $controller->$method();
                break;
            }
        }
    }
}

?>