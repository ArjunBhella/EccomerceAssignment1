<?php

namespace app\controllers;

use app\core\Controller;

class MainController extends Controller
{
    public function index()
    {
        //when called it wull use the Controller.php's view method to add the view
        $this->view('Main/index');
    }

    public function aboutUs()
    {
        $this->view('Main/about_us');
    }
}
?>


